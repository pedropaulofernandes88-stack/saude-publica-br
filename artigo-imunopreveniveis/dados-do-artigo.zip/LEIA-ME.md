# Material suplementar

**Óbitos por doenças imunopreveníveis no Brasil, 2015–2024: um instrumento
oficial que descreve o calendário vacinal de 2010**

Pedro Paulo Fernandes · Saúde em Dado — saudeemdado.com

---

## O que há neste pacote

| pasta | conteúdo |
|---|---|
| `manuscrito/` | o artigo em Markdown, HTML e PDF |
| `tabelas/` | as dezesseis tabelas do artigo, em CSV |
| `analise/` | as saídas do script de análise, em grão mais fino |
| `codigo/` | os três arquivos Python que produzem tudo o que está aqui |
| `MANIFESTO.csv` | tamanho, linhas, colunas e SHA-256 de cada arquivo |

Todos os CSV estão em UTF-8, com vírgula como separador de campo e ponto como
separador decimal — o formato de máquina. As tabelas **do manuscrito** aparecem
lá com a formatação de leitura brasileira (ponto no milhar, vírgula no decimal);
os CSV daqui são a fonte, não a página.

## Como reproduzir

O pacote é derivado de microdados públicos, e os três scripts de `codigo/` são
o caminho inteiro. Eles esperam os arquivos do SIM em `data/raw/SIM` — os
`.dbc` por unidade da federação do FTP do DataSUS para 2015–2021, 2024 e 2025,
e os CSV nacionais do OpenDataSUS para 2022 e 2023.

```
python scripts/analise_mortes_imunopreveniveis.py
python artigo-imunopreveniveis/gerar_tabelas.py
```

O segundo não depende do primeiro: ele reagrega o microdado por conta própria,
importando as listas de CID-10 e a derivação do óbito do primeiro. É deliberado
— ler um CSV já gravado faria o artigo descrever, sem avisar, um dado que
poderia ter mudado.

## O que os números são, e o que não são

As contagens deste artigo são de **óbitos cuja causa básica é uma doença com
vacina disponível**. Não são mortes evitáveis: faltam a eficácia vacinal, que
nunca é total, e a situação vacinal de quem morreu, que o SIM não registra.
Todo total é um teto, e a §4.4 do manuscrito lista as demais limitações.

## Fontes

Todas de domínio público:

- Sistema de Informações sobre Mortalidade (SIM) — DataSUS e OpenDataSUS
- Programa Nacional de Imunizações (PNI/RNDS) — OpenDataSUS
- Estimativas populacionais e Censo 2022 — IBGE
- Lista Brasileira de Causas de Mortes Evitáveis — notas técnicas do
  TabNet/DataSUS: `Obitos_Evitaveis_0_a_4_anos.pdf` e
  `Obitos_Evitaveis_5_a_74_anos.pdf`

Nenhum dado individual é publicado — apenas agregados.

## Licença

Código sob licença MIT, como o restante do repositório. Tabelas e texto podem
ser reutilizados com citação. Ao usar, cite também as fontes primárias acima.
