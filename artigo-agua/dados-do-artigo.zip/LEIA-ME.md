# Mortes evitáveis por doença infecciosa intestinal no Brasil, 2015–2024

Pacote de dados, figuras e código do manuscrito.

## O que tem aqui

    manuscrito.md            o texto
    tabelas/                 as dezesseis tabelas, em CSV: onze do desenho
                             transversal (tabela_N) e cinco do painel (tabela_pN)
    figuras/                 as nove figuras, em PNG a 300 dpi
    codigo/                  as duas análises, o estimador e os quatro geradores
    referencia/              a nota técnica oficial da Lista Brasileira
    MANIFESTO.csv            inventário com SHA-256 de cada arquivo

## Como reproduzir

    python codigo/analise_agua_painel.py          # a análise PRIMÁRIA (~30 min)
    python codigo/gerar_tabelas_painel.py         # transporta as tabelas do painel
    python codigo/gerar_figuras_painel.py         # desenha as figuras do painel
    python codigo/analise_agua_mortalidade.py     # o desenho transversal
    python codigo/gerar_tabelas.py                # formata para o artigo
    python codigo/gerar_figuras.py                # redesenha as figuras

As análises reexecutam a partir dos marts publicados do projeto. Os critérios de
refutação estão escritos no cabeçalho de cada script, antes de qualquer
resultado. No transversal, o quarto está rotulado como **post-hoc** porque foi
concebido depois de observar os dados.

## O que este desenho NÃO autoriza

É ecológico. A unidade é o município, e nada aqui autoriza afirmar que a pessoa
que morreu consumiu água não vigiada. E ausência de registro de vigilância não é
água contaminada: é ausência da prova.

Além disso, a leitura causal está **refutada pelos próprios dados**: o painel de
efeitos fixos não reproduz a associação que o desenho transversal mede. As onze
tabelas do transversal ficam no pacote como descrição, e não como evidência de
efeito. O que elas documentam está na §4 do manuscrito.
