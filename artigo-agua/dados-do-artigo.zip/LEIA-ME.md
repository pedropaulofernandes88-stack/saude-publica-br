# Mortes evitáveis por doença infecciosa intestinal no Brasil, 2015–2024

Pacote de dados, figuras e código do manuscrito.

## O que tem aqui

    manuscrito.md            o texto
    tabelas/                 as onze tabelas, em CSV
    figuras/                 as cinco figuras, em PNG a 300 dpi
    codigo/                  a análise e os dois geradores
    referencia/              a nota técnica oficial da Lista Brasileira
    MANIFESTO.csv            inventário com SHA-256 de cada arquivo

## Como reproduzir

    python codigo/analise_agua_mortalidade.py     # reescreve as tabelas
    python codigo/gerar_tabelas.py                # formata para o artigo
    python codigo/gerar_figuras.py                # redesenha as figuras

A análise reexecuta a partir dos marts publicados do projeto. Os critérios de
refutação estão escritos no cabeçalho de `analise_agua_mortalidade.py`, antes de
qualquer resultado — inclusive o quarto, que está rotulado como **post-hoc**
porque foi concebido depois de observar os dados.

## O que este desenho NÃO autoriza

É ecológico. A unidade é o município, e nada aqui autoriza afirmar que a pessoa
que morreu consumiu água não vigiada. E ausência de registro de vigilância não é
água contaminada: é ausência da prova.
